<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture
- Simulated NonStop data lives in `src/data/*.json` (copied from the team's Python repo); client uses downsampled `metrics.json`, server AI uses `metrics-full.json` — keep the client bundle small.
- AI calls go through `src/routes/api/relay.ts` → `src/lib/relay.server.ts` (Responses API, strict JSON schema); the server rejects any command not in `commands.json`.
- `src/lib/scripted.ts` is the demo fallback used on AI error/timeout or presenter toggle; keep it in sync with the demo incident.
- Scripted CPU incident replies adapt `src/data/demo_responses.json` using replay time, role and executed command history; recovery is reported only after the simulated fix output, to avoid repeated checks or premature resolution.
- Permission and two-person-review rules live only in `src/lib/permissions.ts` (tested in `src/test/permissions.test.ts`).
- App state (sim clock, user, chat, knowledge, audit) is in-memory React context in `src/lib/store.tsx`; it resets on reload by design.
