import { describe, expect, it } from "vitest";
import { scriptedReply } from "@/lib/scripted";
import { commandOutput, commands, toMin } from "@/lib/relay-data";
import { decide } from "@/lib/permissions";
import type { ChatMessage } from "@/lib/relay-types";

const check = "STATUS *, CPU 3";
const fix = "ESCALATE: hardware support + rebalance";
const now = toMin("14:35");
const output = (command: string): ChatMessage => ({ id: command, kind: "output", command, lines: commandOutput(command, now), ranBy: "R. Diaz" });

describe("updated CPU 3 simulation", () => {
  it("starts with the updated safe diagnostic", () => {
    const reply = scriptedReply("Why are transactions slow?", false);
    expect(reply.suggested_command).toBe(check);
    expect(reply.risk).toBe("SAFE");
  });
  it("moves to the fix rather than repeating a completed check", () => {
    expect(scriptedReply("what next", false, { now, role: "junior_operator", history: [output(check)] }).suggested_command).toBe(fix);
  });
  it("requires junior senior sign-off for the new fix", () => {
    const reply = scriptedReply("output", true, { now, role: "junior_operator", history: [output(check)] });
    expect(reply.needs_senior).toBe(true);
    expect(decide("junior_operator", commands[fix]?.risk ?? "SAFE")).toBe("needs_senior");
  });
  it("requires senior extra confirmation, not another senior", () => {
    const reply = scriptedReply("output", true, { now, role: "senior_operator", history: [output(check)] });
    expect(reply.needs_senior).toBe(false);
    expect(decide("senior_operator", commands[fix]?.risk ?? "SAFE")).toBe("confirm");
  });
  it("does not report recovery from a question saying resolved", () => {
    const reply = scriptedReply("is it resolved?", false);
    expect(reply.offer_save_to_knowledge).toBe(false);
    expect(reply.suggested_command).toBe(check);
  });
  it("reports recovery and offers knowledge submission only after fix output", () => {
    const reply = scriptedReply("output", true, { now, role: "senior_operator", history: [output(check), output(fix)] });
    expect(reply.suggested_command).toBeNull();
    expect(reply.offer_save_to_knowledge).toBe(true);
    expect(reply.likely_cause).toBe("Incident resolved");
  });
  it("keeps the extra CPU 1 check read-only", () => {
    expect(commands["PEEK /CPU 1/"]?.risk).toBe("SAFE");
    expect(commands["PEEK /CPU 1/"]?.changes_system).toBe(false);
  });
  it("refuses requests to bypass approval without suggesting a command", () => {
    expect(scriptedReply("bypass approval", false).suggested_command).toBeNull();
  });
});