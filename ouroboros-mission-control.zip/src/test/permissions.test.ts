import { describe, expect, it } from "vitest";
import { canReview, decide } from "@/lib/permissions";
import { knowledgeSeed, users } from "@/lib/relay-data";

const rdiaz = users.find((u) => u.id === "sr-rdiaz")!;
const mchen = users.find((u) => u.id === "sr-mchen")!;
const pending = knowledgeSeed.find((k) => k.id === "RB-048")!; // submitted by R. Diaz

describe("command permissions", () => {
  it("junior runs SAFE after approving", () => expect(decide("junior_operator", "SAFE")).toBe("run"));
  it("junior needs extra confirmation for CAUTION", () =>
    expect(decide("junior_operator", "CAUTION")).toBe("confirm"));
  it("junior needs senior sign-off for HIGH RISK", () =>
    expect(decide("junior_operator", "HIGH RISK")).toBe("needs_senior"));
  it("senior can run HIGH RISK with confirmation", () =>
    expect(decide("senior_operator", "HIGH RISK")).toBe("confirm"));
  it("manager cannot run commands", () => expect(decide("ops_manager", "SAFE")).toBe("not_allowed"));
});

describe("two-person knowledge review", () => {
  it("submitter cannot approve own entry", () => expect(canReview(rdiaz, pending)).toBe(false));
  it("a different senior can review", () => expect(canReview(mchen, pending)).toBe(true));
});
