import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Ouroboros — AI for Mission-Critical Systems" },
      { name: "description", content: "Why Ouroboros exists: retiring NonStop experts, junior operators under pressure, and systems that can't go down." },
      { property: "og:title", content: "About Ouroboros" },
      { property: "og:description", content: "CAIL case challenge #5: managing mission-critical systems with AI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: About,
});

const results = [
  ["98.7%", "accuracy"], ["95.8%", "precision"], ["92.9%", "recall"], ["3 / 3", "incidents caught"], ["40 min", "earlier than first disk alert"],
];

const pillars = [
  { t: "Plain English → commands", d: "Questions become catalog commands with a SAFE / CAUTION / HIGH RISK label. Nothing runs until a human approves." },
  { t: "Understands system health", d: "Rolling z-score + Isolation Forest + trend checks flag anomalies, then the AI explains them with the exact numbers." },
  { t: "Preserves expertise", d: "Senior fixes become runbooks with two-person review. The AI cites who wrote and reviewed every step." },
  { t: "Guides decisions", d: "Always starts with a read-only check, gives confidence, and escalates to the on-call senior when the role requires it." },
];

function About() {
  return (
    <main className="mx-auto max-w-5xl space-y-14 px-5 py-12">
      <section>
        <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary">Catalyst 2026 · Challenge #5 · CAIL</p>
        <h1 className="mt-3 text-4xl font-semibold leading-tight tracking-tight md:text-5xl">
          When a bank's core system stumbles at 2 AM, <span className="text-signal">the expert shouldn't be the only one who knows what to do.</span>
        </h1>
        <p className="mt-4 max-w-2xl text-lg text-muted-foreground">
          HPE NonStop runs ATMs, card payments and telecom for millions. The operators who know it best are retiring. Ouroboros sits inside CAIL's terminal and turns their knowledge into guidance any new operator can follow, safely.
        </p>
        <Button asChild className="mt-6"><Link to="/">Open Mission Control</Link></Button>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {[["Who it affects", "Junior operators on night shifts, and the customers waiting at ATMs and checkouts."],
          ["The problem", "Alerts from ASAP, Prognosis and EMS say what broke, not what to do. Answers live in seniors' heads."],
          ["Why it matters", "Every minute of degraded capacity means slower payments and lost trust."]].map(([t, d]) => (
          <div key={t} className="glass p-5"><h2 className="font-medium">{t}</h2><p className="mt-2 text-sm text-muted-foreground">{d}</p></div>
        ))}
      </section>

      <section>
        <h2 className="text-2xl font-semibold">How it works</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          {pillars.map((p) => <div key={p.t} className="glass p-5"><h3 className="font-medium text-primary">{p.t}</h3><p className="mt-2 text-sm text-muted-foreground">{p.d}</p></div>)}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold">Detection results <span className="text-sm font-normal text-muted-foreground">on an unseen day</span></h2>
        <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-5">
          {results.map(([v, l]) => <div key={l} className="glass p-4 text-center"><div className="text-2xl font-semibold text-signal">{v}</div><div className="mt-1 text-xs text-muted-foreground">{l}</div></div>)}
        </div>
      </section>

      <section className="glass p-6">
        <h2 className="text-xl font-semibold">Why it's realistic</h2>
        <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
          <li>• Adds to the bank's existing monitoring tools instead of replacing them.</li>
          <li>• Human-in-the-loop by design: role checks, senior sign-off, full audit trail.</li>
          <li>• AI can only pick from an approved command catalog, so it can't invent risky actions.</li>
          <li>• Works as a feature of CAIL's terminal, one of only three vendors in this space.</li>
        </ul>
        <p className="mt-4 text-xs text-muted-foreground">All system data is simulated. Command syntax is illustrative and must be verified against HPE NonStop manuals.</p>
        <p className="mt-2 text-xs text-muted-foreground">Team #24 · Adan Abdullahi · Rong Hao · Dhruva Rau</p>
      </section>
    </main>
  );
}
