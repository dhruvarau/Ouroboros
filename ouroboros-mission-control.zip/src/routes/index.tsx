import { createFileRoute } from "@tanstack/react-router";
import { HealthPanel } from "@/components/HealthPanel";
import { ChatPanel } from "@/components/ChatPanel";
import { CriticalIncident } from "@/components/CriticalIncident";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ouroboros — Mission Control for HPE NonStop" },
      { name: "description", content: "Ask a mission-critical NonStop system questions in plain English. Ouroboros explains alerts, suggests safe commands and waits for your approval." },
      { property: "og:title", content: "Ouroboros — Mission Control for HPE NonStop" },
      { property: "og:description", content: "AI co-pilot that helps new IT operators monitor and troubleshoot NonStop systems while preserving senior expertise." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="mx-auto max-w-[1500px] px-6 py-6">
      <div className="mb-5">
        <h1 className="text-2xl font-semibold tracking-tight">System Overview</h1>
        <p className="text-sm text-muted-foreground">Monitor health, understand alerts, and act safely with AI guidance.</p>
      </div>
      <CriticalIncident />
      <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,55fr)_minmax(0,45fr)]">
        <HealthPanel />
        <div className="relative min-h-[560px] lg:min-h-0"><div className="flex h-[70vh] flex-col lg:absolute lg:inset-0 lg:h-auto"><ChatPanel /></div></div>
      </div>

    </main>
  );
}
