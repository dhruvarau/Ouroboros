import { createFileRoute } from "@tanstack/react-router";
import { permissionRules } from "@/lib/relay-data";
import { useRelay } from "@/lib/store";

export const Route = createFileRoute("/audit")({
  head: () => ({
    meta: [
      { title: "Audit Log — Ouroboros" },
      { name: "description", content: "Every question, approval, sign-off and command, recorded for review." },
      { property: "og:title", content: "Audit Log — Ouroboros" },
      { property: "og:description", content: "Full trail of human approvals and commands on the NonStop system." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuditPage,
});

function AuditPage() {
  const { audit } = useRelay();
  return (
    <main className="mx-auto max-w-5xl space-y-6 px-5 py-8">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Audit log</h1>
        <ul className="mt-3 space-y-1 text-sm text-muted-foreground">
          {permissionRules.map((r) => <li key={r}>• {r}</li>)}
        </ul>
      </div>
      <div className="glass overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary/60 text-left font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr><th className="px-4 py-2">Sim time</th><th className="px-4 py-2">Who</th><th className="px-4 py-2">Action</th><th className="px-4 py-2">Detail</th></tr>
          </thead>
          <tbody className="divide-y divide-border">
            {audit.length === 0 && <tr><td colSpan={4} className="px-4 py-8 text-center text-muted-foreground">Nothing yet. Ask Ouroboros a question on Mission Control.</td></tr>}
            {audit.map((a) => (
              <tr key={a.id}>
                <td className="px-4 py-2 font-mono text-xs">{a.sim}</td>
                <td className="px-4 py-2">{a.actor}</td>
                <td className="px-4 py-2">{a.action}</td>
                <td className="px-4 py-2 font-mono text-xs text-muted-foreground">{a.detail}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
