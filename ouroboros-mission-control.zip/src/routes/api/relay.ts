import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/relay")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = await request.json();
        const { askRelay } = await import("@/lib/relay.server");
        try {
          return await askRelay(request, body);
        } catch (e) {
          if (request.signal.aborted) return new Response(null, { status: 499 });
          return Response.json({ error: String(e) }, { status: 500 });
        }
      },
    },
  },
});
