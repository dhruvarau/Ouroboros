import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { RiskBadge } from "@/components/RiskBadge";
import { canReview, canSubmitKnowledge } from "@/lib/permissions";
import { fmtMin, knowledgeRules, users } from "@/lib/relay-data";
import { useRelay } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/knowledge")({
  head: () => ({
    meta: [
      { title: "Expert Knowledge — Ouroboros" },
      { name: "description", content: "Senior operator runbooks with two-person review, so decades of NonStop expertise stay usable." },
      { property: "og:title", content: "Expert Knowledge — Ouroboros" },
      { property: "og:description", content: "Two-person reviewed runbooks the AI cites when guiding operators." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: KnowledgePage,
});

const nameOf = (id: string | null) => users.find((u) => u.id === id)?.name ?? "—";
const when = (s: string | null) => (s ? s.replace("T", " ") : "—");
const sourceLabel: Record<string, string> = {
  senior_note: "Senior note",
  past_incident: "Past incident",
  custom: "New submission",
};
const accent: Record<string, string> = {
  approved: "bg-safe",
  pending: "bg-caution",
  rejected: "bg-danger",
};
const headerTint: Record<string, string> = {
  approved: "bg-safe/10",
  pending: "bg-caution/10",
  rejected: "bg-danger/10",
};

function StepMark({ n }: { n: number }) {
  return (
    <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-sm bg-primary font-mono text-[10px] font-semibold text-primary-foreground">
      {n}
    </span>
  );
}

function MetaCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <span className="font-mono text-[10px] uppercase tracking-wider text-secondary-foreground">{label}</span>
      <span className="text-right text-xs text-card-foreground">{value}</span>
    </div>
  );
}

function KnowledgePage() {
  const { knowledge, setKnowledge, user, now, log } = useRelay();
  const [title, setTitle] = useState("");
  const [steps, setSteps] = useState("");
  const stamp = `2026-10-17T${fmtMin(now)}`;

  function review(id: string, ok: boolean) {
    const reason = ok ? undefined : window.prompt("Reason for rejecting?") ?? "No reason given";
    setKnowledge((k) => k.map((e) => (e.id === id ? { ...e, status: ok ? "approved" : "rejected", reviewed_by: user.id, reviewed_at: stamp, review_reason: reason } : e)));
    log(ok ? "Approved knowledge" : "Rejected knowledge", id);
  }

  function submit() {
    if (!title.trim() || !steps.trim()) return;
    const id = `RB-${String(50 + knowledge.length).padStart(3, "0")}`;
    setKnowledge((k) => [...k, { id, title, incident_type: "custom", steps: steps.split("\n").filter(Boolean), source_type: "senior_note", status: "pending", submitted_by: user.id, submitted_at: stamp, reviewed_by: null, reviewed_at: null, times_used: 0 }]);
    log("Submitted knowledge", id);
    setTitle(""); setSteps("");
  }

  return (
    <main className="mx-auto max-w-5xl space-y-6 px-5 py-8">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Expert knowledge, <span className="text-signal">kept alive</span></h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">The knowledge base grows with each approved runbook, giving Ouroboros more verified guidance for future incidents.</p>
        <p className="mt-2 max-w-2xl text-muted-foreground">Fixes from senior operators become runbooks the AI can cite. A second, different senior must approve each one before it's used.</p>
      </div>

      <section className="overflow-hidden rounded-lg border border-primary/25 bg-card shadow-card">
        <h2 className="border-b border-border bg-secondary/70 px-4 py-2 font-mono text-[11px] uppercase tracking-wider text-secondary-foreground">
          Review rules
        </h2>
        <ol className="grid gap-x-8 gap-y-2 p-4 text-sm text-card-foreground sm:grid-cols-2">
          {knowledgeRules.map((r, i) => (
            <li key={r} className="flex gap-2.5">
              <StepMark n={i + 1} />
              <span>{r}</span>
            </li>
          ))}
        </ol>
      </section>

      <div className="grid gap-5 md:grid-cols-2">
        {knowledge.map((e) => (
          <article key={e.id} className="flex flex-col overflow-hidden rounded-lg border border-primary/25 bg-card shadow-card">
            <div className={cn("h-1.5", accent[e.status])} />
            <header className={cn("flex flex-wrap items-center gap-2 border-b border-border px-4 py-2.5", headerTint[e.status])}>
              <span className="rounded-sm bg-primary px-2 py-0.5 font-mono text-[11px] font-semibold tracking-wider text-primary-foreground">{e.id}</span>
              <RiskBadge value={e.status} strong />
              <span className="ml-auto rounded-sm border border-border bg-background px-2 py-0.5 font-mono text-[11px] text-secondary-foreground">
                used {e.times_used}×
              </span>
            </header>

            <div className="flex-1 p-4">
              <h2 className="text-lg font-semibold leading-snug text-card-foreground">{e.title}</h2>
              <p className="mt-1.5 font-mono text-[10px] uppercase tracking-wider text-secondary-foreground">
                {sourceLabel[e.source_type] ?? e.source_type} · {e.incident_type.replace("_", " ")}
              </p>

              <ol className="mt-3 space-y-2 rounded-md border border-border bg-muted/60 p-3">
                {e.steps.map((s, i) => (
                  <li key={s} className="flex gap-2.5 text-sm leading-snug text-card-foreground">
                    <StepMark n={i + 1} />
                    <span>{s}</span>
                  </li>
                ))}
              </ol>

              {e.note && (
                <p className="mt-3 rounded-md border-l-2 border-primary bg-secondary/60 px-3 py-2 text-xs leading-relaxed text-card-foreground">
                  {e.note}
                </p>
              )}

              {e.review_reason && (
                <p className="mt-3 rounded-md border-l-2 border-danger bg-danger/10 px-3 py-2 text-xs leading-relaxed text-card-foreground">
                  <span className="font-semibold text-danger">Reviewer's reason:</span> {e.review_reason}
                </p>
              )}

              {e.status === "pending" && (
                canReview(user, e) ? (
                  <div className="mt-3 flex flex-wrap items-center gap-2 rounded-md border border-caution/50 bg-caution/10 px-3 py-2.5">
                    <span className="mr-auto text-xs text-card-foreground">Second senior review required.</span>
                    <Button size="sm" onClick={() => review(e.id, true)}>Approve</Button>
                    <Button size="sm" variant="outline" onClick={() => review(e.id, false)}>Reject</Button>
                  </div>
                ) : (
                  <p className="mt-3 rounded-md border border-caution/50 bg-caution/10 px-3 py-2 text-xs leading-relaxed text-card-foreground">
                    {e.submitted_by === user.id ? "You submitted this. A different senior must review it." : "Awaiting review by a senior operator."}
                  </p>
                )
              )}
            </div>

            <footer className="grid gap-x-8 gap-y-1.5 border-t border-border bg-secondary/50 px-4 py-2.5 sm:grid-cols-2">
              <MetaCell label="Submitted" value={`${nameOf(e.submitted_by)} · ${when(e.submitted_at)}`} />
              <MetaCell label="Reviewed" value={e.reviewed_by ? `${nameOf(e.reviewed_by)} · ${when(e.reviewed_at)}` : "not yet reviewed"} />
            </footer>
          </article>
        ))}
      </div>

      {canSubmitKnowledge(user) ? (
        <section className="overflow-hidden rounded-lg border border-primary/25 bg-card shadow-card">
          <h2 className="border-b border-border bg-secondary/70 px-4 py-2 font-mono text-[11px] uppercase tracking-wider text-secondary-foreground">
            Submit a new fix
          </h2>
          <div className="space-y-3 p-4">
            <div>
              <label htmlFor="kb-title" className="font-mono text-[10px] uppercase tracking-wider text-secondary-foreground">Title</label>
              <input id="kb-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Escalate when CPU 2 stays above 90%" className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" />
            </div>
            <div>
              <label htmlFor="kb-steps" className="font-mono text-[10px] uppercase tracking-wider text-secondary-foreground">Steps — one per line</label>
              <textarea id="kb-steps" value={steps} onChange={(e) => setSteps(e.target.value)} placeholder={"PEEK CPU 2\nTMFCOM STATUS TMF"} rows={4} className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" />
            </div>
            <Button onClick={submit}>Submit for review</Button>
          </div>
        </section>
      ) : (
        <p className="text-sm text-muted-foreground">Switch to a senior operator (top right) to submit or review fixes.</p>
      )}
    </main>
  );
}
