import type { KnowledgeEntry, Risk, RoleKey, User } from "./relay-data";

export type Decision = "run" | "confirm" | "needs_senior" | "not_allowed";

/** Mirrors users.json: nothing runs without Approve; juniors run SAFE, confirm CAUTION, need senior for HIGH RISK. */
export function decide(role: RoleKey, risk: Risk): Decision {
  if (role === "ops_manager") return "not_allowed";
  if (role === "junior_operator") {
    if (risk === "SAFE") return "run";
    if (risk === "CAUTION") return "confirm";
    return "needs_senior";
  }
  return risk === "SAFE" ? "run" : "confirm";
}

export function canApproveOthers(user: User) {
  return user.role === "senior_operator";
}

export function canSubmitKnowledge(user: User) {
  return user.role === "senior_operator";
}

/** Two-person review: a different senior must approve a pending entry. */
export function canReview(user: User, entry: KnowledgeEntry) {
  return user.role === "senior_operator" && entry.status === "pending" && entry.submitted_by !== user.id;
}
