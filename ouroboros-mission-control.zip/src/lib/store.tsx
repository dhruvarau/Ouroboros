import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { fmtMin, knowledgeSeed, scenarios, users, type KnowledgeEntry, type User } from "./relay-data";
import type { ChatMessage } from "./relay-types";

export type Escalation = { id: string; sim: string; from: string; to: string; incident: string | null; summary: string; status: "pending" | "approved" | "rejected"; reviewedBy?: string };
export type AuditEntry = { id: string; sim: string; actor: string; action: string; detail: string };

type Store = {
  now: number;
  setNow: (n: number) => void;
  user: User;
  setUserId: (id: string) => void;
  backup: boolean;
  setBackup: (b: boolean) => void;
  messages: ChatMessage[];
  setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  knowledge: KnowledgeEntry[];
  setKnowledge: React.Dispatch<React.SetStateAction<KnowledgeEntry[]>>;
  audit: AuditEntry[];
  escalations: Escalation[];
  setEscalations: React.Dispatch<React.SetStateAction<Escalation[]>>;
  log: (action: string, detail: string, actor?: string) => void;
};

const Ctx = createContext<Store | null>(null);
export const uid = () => Math.random().toString(36).slice(2, 10);

export function RelayProvider({ children }: { children: ReactNode }) {
  const [now, setNow] = useState(scenarios[1]!.time);
  const [userId, setUserId] = useState("jr-ops-03");
  const [backup, setBackup] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [knowledge, setKnowledge] = useState<KnowledgeEntry[]>(knowledgeSeed);
  const [escalations, setEscalations] = useState<Escalation[]>([]);
  const [audit, setAudit] = useState<AuditEntry[]>([]);
  const user = users.find((u) => u.id === userId)!;

  const log = useCallback(
    (action: string, detail: string, actor?: string) =>
      setAudit((a) => [{ id: uid(), sim: fmtMin(now), actor: actor ?? user.name, action, detail }, ...a]),
    [now, user.name],
  );

  useEffect(() => {
    setMessages([]);
  }, [now]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      const typing = t?.tagName === "INPUT" || t?.tagName === "TEXTAREA";
      if (e.shiftKey && (e.key === "D" || e.key === "d") && (!typing || e.altKey)) {
        e.preventDefault();
        setBackup((b) => !b);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const value = useMemo(
    () => ({ now, setNow, user, setUserId, backup, setBackup, messages, setMessages, knowledge, setKnowledge, audit, log, escalations, setEscalations }),
    [now, user, backup, messages, knowledge, audit, log, escalations],
  );
  return (
    <Ctx.Provider value={value}>
      {children}
      {backup && <span aria-hidden className="fixed bottom-2 right-2 z-50 size-1.5 rounded-full bg-backup-dot" />}
    </Ctx.Provider>
  );
}

export function useRelay() {
  const c = useContext(Ctx);
  if (!c) throw new Error("RelayProvider missing");
  return c;
}
