import metricsRaw from "@/data/metrics.json";
import eventsRaw from "@/data/events.json";
import incidentsRaw from "@/data/incidents.json";
import anomaliesRaw from "@/data/anomalies.json";
import commandsRaw from "@/data/commands.json";
import knowledgeRaw from "@/data/knowledge.json";
import usersRaw from "@/data/users.json";

export type Risk = "SAFE" | "CAUTION" | "HIGH RISK";
export type Metric = (typeof metricsRaw)[number];
export type SysEvent = (typeof eventsRaw)[number];
export type Incident = (typeof incidentsRaw)[number];
export type Anomaly = (typeof anomaliesRaw)[number];
export type Command = {
  risk: Risk;
  changes_system: boolean;
  needs_senior?: boolean;
  purpose: string;
  impact?: string;
  source: string;
  output: Record<string, string[]>;
};
export type KnowledgeEntry = {
  id: string;
  title: string;
  incident_type: string;
  steps: string[];
  source_type: string;
  status: "approved" | "pending" | "rejected";
  submitted_by: string;
  submitted_at: string;
  reviewed_by: string | null;
  reviewed_at: string | null;
  times_used: number;
  note?: string;
  review_reason?: string | undefined;
};
export type RoleKey = "junior_operator" | "senior_operator" | "ops_manager";
export type User = { id: string; name: string; role: RoleKey; shift: string; on_call: boolean };

export const metrics: Metric[] = metricsRaw;
export const events: SysEvent[] = eventsRaw;
export const incidents: Incident[] = incidentsRaw;
export const anomalies: Anomaly[] = anomaliesRaw;
export const commands = commandsRaw as unknown as Record<string, Command>;
export const knowledgeSeed = knowledgeRaw.entries as KnowledgeEntry[];
export const knowledgeRules = knowledgeRaw.review_rules;
export const users = usersRaw.users as User[];
export const roleLabels: Record<RoleKey, string> = {
  junior_operator: "Junior Operator",
  senior_operator: "Senior Operator",
  ops_manager: "Operations Manager",
};
export const permissionRules = usersRaw.rules;
export const onCallSenior = users.find((u) => u.role === "senior_operator" && u.on_call)!;

export const toMin = (t: string) => {
  const hm = t.length > 5 ? t.slice(11, 16) : t;
  return Number(hm.slice(0, 2)) * 60 + Number(hm.slice(3, 5));
};
export const fmtMin = (m: number) =>
  `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;

export function incidentAt(now: number): Incident | null {
  return incidents.find((i) => toMin(i.start) <= now && now <= toMin(i.end)) ?? null;
}

export function metricAt(now: number): Metric {
  let last = metrics[0]!;
  for (const m of metrics) {
    if (toMin(m.t) <= now) last = m;
    else break;
  }
  return last;
}

export function metricsUntil(now: number, window = 240): Metric[] {
  return metrics.filter((m) => {
    const t = toMin(m.t);
    return t <= now && t >= now - window;
  });
}

export function eventsUntil(now: number): SysEvent[] {
  return events.filter((e) => toMin(e.time) <= now);
}

export function commandOutput(cmd: string, now: number): string[] {
  const c = commands[cmd];
  if (!c) return ["Command not in catalog."];
  const inc = incidentAt(now);
  return (inc && c.output[`during_${inc.id}`]) || c.output["normal"] || ["Command completed. No change reported."];
}

export const scenarios = [
  { label: "Payment loop", time: toMin("02:20"), id: "INC-001" },
  { label: "CPU 3 failure", time: toMin("14:35"), id: "INC-002" },
  { label: "Disk filling", time: toMin("19:50"), id: "INC-003" },
  { label: "Quiet shift", time: toMin("10:00"), id: null },
];
