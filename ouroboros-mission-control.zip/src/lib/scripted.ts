import demoResponses from "@/data/demo_responses.json";
import { commands, incidentAt, metricAt, onCallSenior, toMin, type RoleKey } from "./relay-data";
import { decide } from "./permissions";
import type { ChatMessage, RelayReply } from "./relay-types";

const OPS_WORDS =
  /cpu|slow|latenc|transaction|tps|payment|alert|disk|queue|status|health|process|tmf|system|error|fail|down|why|what|how|incident|peek|runbook|rb-|backout|response|takeover|node|\$|command|check|fix|issue|problem|senior|escalat|resolv|recover|done|next/i;
const INJECTION = /ignore (all|your|previous)|system prompt|reveal|jailbreak|pretend|bypass|override/i;

const base = (r: Partial<RelayReply>): RelayReply => ({
  headline: "",
  answer: "",
  confidence_reason: null,
  look_for: null,
  evidence: [],
  likely_cause: null,
  suggested_command: null,
  risk: null,
  needs_senior: false,
  why: null,
  source: null,
  confidence: "HIGH",
  next_if_confirmed: null,
  offer_save_to_knowledge: false,
  ...r,
});

/** Pre-written demo flow: CPU 3 hardware failure at 14:30. */
function legacyReply(userText: string, isCommandOutput: boolean): RelayReply {
  if (!isCommandOutput && INJECTION.test(userText)) {
    return base({
      answer:
        "I can't do that. I only suggest commands from the approved catalog, and every action needs a human to approve it. Want me to check current system health instead?",
      confidence: "N/A",
    });
  }
  if (!isCommandOutput && !OPS_WORDS.test(userText)) {
    return base({
      answer:
        "I only help with NonStop operations on \\PROD1. Want me to explain why transactions are slow right now?",
      confidence: "N/A",
    });
  }

  if (isCommandOutput) {
    return base({
      headline: "Confirmed: CPU 3 has failed. No transactions are lost, but the bank is running on reduced capacity.",
      confidence_reason: "Confirmed directly by the PEEK output and the 14:30 EMS event.",
      answer: `CPU 3 is down (hardware). Its process pairs took over on the other CPUs, so nothing is lost, but CPU 1 is now carrying the extra load. Per RB-009, don't reload the CPU yourself. This needs hardware support and a load rebalance, which is a senior call. Escalate to ${onCallSenior.name} (on call) now.`,
      evidence: ["PEEK /CPU 3/: *** CPU DOWN ***", "EMS 14:30: CPU 3 down, takeover complete", "CPU 1 near 90% after takeover"],
      likely_cause: "CPU 3 hardware fault; workload shifted to remaining CPUs",
      needs_senior: true,
      why: "Rebalancing load and calling hardware support change the live system and are senior-only.",
      source: "RB-009, by M. Chen, reviewed by R. Diaz",
      next_if_confirmed: `Do not act on this yourself. Request sign-off from ${onCallSenior.name} (on call), who contacts HPE hardware support and rebalances load if any CPU stays above 90% for 10+ minutes.`,
    });
  }

  const m = metricAt(toMin("14:34"));
  return base({
    headline: `Payments are slowing: responses take about ${Math.round(m.response_ms)} ms instead of ~55 ms because one of four processors (CPU 3) has stopped.`,
    confidence_reason: "CPU 3 dropped to 0% the same minute latency spiked, matching RB-009, but hardware failure is not confirmed until the check runs.",
    look_for: 'Look for "*** CPU DOWN ***". If you see it, the hardware has failed; if CPU 3 shows as busy instead, it is a load issue.',
    answer: `ASAP raised a Critical (level 1 of 4) alert at 14:30. Response time jumped to about ${Math.round(m.response_ms)} ms (normally ~55 ms) at 14:30 because CPU 3 dropped to 0%. Its work moved to CPU 1, now ~${Math.round(m.cpu1_pct)}% busy, so transactions queue up. Let's confirm with a read-only check.`,
    evidence: [
      `CPU 3 at ${Math.round(m.cpu3_pct)}% since 14:30`,
      `CPU 1 at ${Math.round(m.cpu1_pct)}%`,
      `Response time ${Math.round(m.response_ms)} ms vs ~55 ms normal`,
      "Anomaly flagged 14:30 (Isolation Forest)",
    ],
    likely_cause: "CPU 3 hardware failure; capacity reduced after takeover",
    confidence: "MEDIUM",
    suggested_command: "PEEK /CPU 3/",
    risk: "SAFE",
    why: "Read-only. Shows whether CPU 3 is actually down. It changes nothing.",
    source: "PEEK Reference Manual",
    next_if_confirmed: `If confirmed, do not fix this yourself. Request sign-off from ${onCallSenior.name} (on call) for hardware support and load rebalancing. Risk: rebalancing briefly moves live work between CPUs.`,
  });
}

type DemoContext = { now: number; role: RoleKey; history: ChatMessage[] };
const CHECK = "STATUS *, CPU 3";
const FIX = "ESCALATE: hardware support + rebalance";

/** Adapt the team's canned replies without letting question keywords fake a completed action. */
export function scriptedReply(
  userText: string,
  isCommandOutput: boolean,
  context: DemoContext = { now: toMin("14:35"), role: "junior_operator", history: [] },
): RelayReply {
  if (!isCommandOutput && (INJECTION.test(userText) || !OPS_WORDS.test(userText))) {
    return legacyReply(userText, false);
  }
  if (incidentAt(context.now)?.id !== "INC-002") return legacyReply(userText, isCommandOutput);

  const outputs = context.history.filter((m) => m.kind === "output");
  const recovered = outputs.some((m) => m.command === FIX && m.lines.some((line) => line.includes("Process pairs restored")));
  const checked = outputs.some((m) =>
    (m.command === CHECK || m.command === "PEEK /CPU 3/") &&
    m.lines.some((line) => /CPU 3 not available|CPU DOWN|No backups available/.test(line)),
  );
  const entryId = recovered ? "q3_after_escalation" : checked ? "q2_after_status" : "q1_latency";
  const entry = demoResponses.responses.find((r) => r.id === entryId);
  if (!entry) return legacyReply(userText, isCommandOutput);
  const reply = base(entry.reply as Partial<RelayReply>);
  const m = metricAt(context.now);

  if (!checked && !recovered) {
    reply.headline = `Payments are slowing: responses take about ${Math.round(m.response_ms)} ms instead of ~55 ms with CPU 3 unavailable.`;
    reply.answer = `CPU 3 failed at 14:30 (ASAP alert). Its programs moved to CPU 1, now about ${Math.round(m.cpu1_pct)}% busy, and responses take about ${Math.round(m.response_ms)} ms instead of ~55 ms. The system is still running with less capacity. Let's confirm which programs moved with a read-only check.`;
    reply.evidence = reply.evidence.map((e) => e.replace("~97%", `~${Math.round(m.cpu1_pct)}%`).replace("~138 ms", `~${Math.round(m.response_ms)} ms`));
    reply.confidence_reason = "The alerts and processor metrics match RB-009; the process takeover still needs a read-only check.";
    reply.look_for = "Look for CPU 3 not available, the programs now running on CPU 1 or CPU 0, and whether their backups are available.";
  } else if (recovered) {
    reply.headline = "The simulated recovery restored CPU 3 and its process pairs.";
    reply.confidence_reason = "The approved fix output confirms CPU 3 reloaded and process pairs restored.";
    reply.look_for = null;
  } else {
    reply.headline = "Payments are still running, but the lost backups leave the bank exposed to a second failure.";
    reply.confidence_reason = "The approved diagnostic output confirms CPU 3 is unavailable and its process pairs took over.";
    reply.look_for = "Look for the HPE support ticket, senior approval and confirmation that CPU 3 and its process pairs were restored.";
  }
  const cmd = reply.suggested_command;
  if (cmd && commands[cmd]) {
    reply.risk = commands[cmd].risk;
    reply.needs_senior = decide(context.role, commands[cmd].risk) === "needs_senior";
    if (cmd === FIX) {
      reply.next_if_confirmed = reply.needs_senior
        ? `Do not reload CPU 3 yourself. Request sign-off from ${onCallSenior.name} (on call) for hardware support and load rebalancing.`
        : "Approve and confirm the simulated hardware support and load rebalance; do not reload CPU 3 yourself.";
    }
  } else if (cmd) {
    reply.suggested_command = null;
    reply.risk = null;
  }
  return reply;
}
