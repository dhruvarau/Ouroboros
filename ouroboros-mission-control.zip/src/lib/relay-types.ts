import type { Risk } from "./relay-data";

export type RelayReply = {
  headline: string;
  answer: string;
  confidence_reason: string | null;
  look_for: string | null;
  evidence: string[];
  likely_cause: string | null;
  suggested_command: string | null;
  risk: Risk | null;
  needs_senior: boolean;
  why: string | null;
  source: string | null;
  confidence: "HIGH" | "MEDIUM" | "LOW" | "N/A";
  next_if_confirmed: string | null;
  offer_save_to_knowledge: boolean;
};

export type ConvoTurn = { role: "user" | "assistant"; content: string };

export type CardStatus = "idle" | "confirming" | "awaiting_senior" | "ran" | "rejected" | "blocked";

export type ChatMessage =
  | { id: string; kind: "user"; text: string }
  | { id: string; kind: "assistant"; reply: RelayReply; status: CardStatus; requestedBy?: string | undefined }
  | { id: string; kind: "output"; command: string; lines: string[]; ranBy: string };
