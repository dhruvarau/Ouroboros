import { cn } from "@/lib/utils";

const styles: Record<string, string> = {
  SAFE: "border-safe/40 bg-safe/10 text-safe",
  CAUTION: "border-caution/40 bg-caution/10 text-caution",
  "HIGH RISK": "border-danger/50 bg-danger/15 text-danger",
  CRITICAL: "border-danger/50 bg-danger/15 text-danger",
  CRIT: "border-danger/50 bg-danger/15 text-danger",
  HIGH: "border-caution/40 bg-caution/10 text-caution",
  WARN: "border-caution/40 bg-caution/10 text-caution",
  MEDIUM: "border-primary/40 bg-primary/10 text-primary",
  INFO: "border-border bg-muted text-muted-foreground",
  approved: "border-safe/40 bg-safe/10 text-safe",
  pending: "border-caution/40 bg-caution/10 text-caution",
  rejected: "border-danger/50 bg-danger/15 text-danger",
};

export function RiskBadge({ value, className, strong }: { value: string; className?: string; strong?: boolean }) {
  return (
    <span
      className={cn(
        "inline-flex items-center whitespace-nowrap rounded-full border px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider",
        styles[value] ?? styles["INFO"],
        strong && "border-2 px-2.5 font-bold",
        className,
      )}
    >
      {value}
    </span>
  );
}
