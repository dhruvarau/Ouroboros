import { incidentAt } from "@/lib/relay-data";
import { useRelay } from "@/lib/store";
import { RiskBadge } from "./RiskBadge";

export function CriticalIncident() {
  const { now } = useRelay();
  const inc = incidentAt(now);
  if (!inc) return null;
  return (
    <section role="alert" aria-label="Critical incident" className="glass relative overflow-hidden bg-danger-tint px-6 py-5 md:py-6">
      <span aria-hidden className="absolute inset-y-0 left-0 w-1.5 bg-danger" />
      <div className="flex flex-wrap items-center gap-x-6 gap-y-3 pl-2">
        <RiskBadge value={inc.severity} strong className="px-3 py-1 text-xs" />
        <div className="min-w-0">
          <h2 className="text-[22px] font-semibold leading-tight tracking-tight text-foreground md:text-2xl">
            {inc.title}
          </h2>
          <p className="mt-1.5 font-mono text-xs text-muted-foreground">
            since {inc.start.slice(11)} · {inc.id}
          </p>
        </div>
      </div>
    </section>
  );
}
