import { useEffect, useRef, useState } from "react";
import { commandOutput, commands, fmtMin, incidentAt, onCallSenior, roleLabels } from "@/lib/relay-data";
import { canApproveOthers, canSubmitKnowledge, decide } from "@/lib/permissions";
import { scriptedReply } from "@/lib/scripted";
import { uid, useRelay } from "@/lib/store";
import type { ChatMessage, ConvoTurn, RelayReply } from "@/lib/relay-types";
import { Button } from "@/components/ui/button";
import { RiskBadge } from "./RiskBadge";
import { Logo } from "./AppHeader";
import { cn } from "@/lib/utils";

const startersBy: Record<string, string[]> = {
  "INC-001": ["Why is the $PAY1 queue growing?", "Explain the most urgent alert", "Is a payment process looping?", "Which runbook covers this?"],
  "INC-002": ["Why are transactions slow?", "What happened to CPU 3?", "Explain the most urgent alert", "What does RB-009 say?"],
  "INC-003": ["Why is $DATA01 filling up?", "How long until the disk is full?", "Explain the most urgent alert", "Which runbook covers this?"],
  none: ["What's the system health right now?", "Any anomalies in the last hour?", "Explain the most recent alert", "What does RB-009 say?"],
};

function toConvo(msgs: ChatMessage[]): ConvoTurn[] {
  return msgs.map((m) =>
    m.kind === "user"
      ? { role: "user", content: m.text }
      : m.kind === "assistant"
        ? { role: "assistant", content: JSON.stringify(m.reply) }
        : { role: "user", content: `COMMAND OUTPUT (${m.command}, approved and run by ${m.ranBy}):\n${m.lines.join("\n")}` },
  );
}

export function ChatPanel() {
  const { messages, setMessages, now, user, backup, setBackup, knowledge, setKnowledge, log, escalations, setEscalations } = useRelay();
  const inc = incidentAt(now);
  const starters = startersBy[inc?.id ?? "none"] ?? startersBy["none"]!;
  const pendingEsc = escalations.filter((e) => e.status === "pending");

  function page(r: RelayReply) {
    if (escalations.some((e) => e.status === "pending" && e.from === user.name && e.incident === (inc?.id ?? null))) return;
    setEscalations((es) => [{ id: uid(), sim: fmtMin(now), from: user.name, to: onCallSenior.name, incident: inc?.id ?? null, summary: r.likely_cause ?? r.answer, status: "pending" }, ...es]);
    log("Escalated", `Paged ${onCallSenior.name} — pending approval${inc ? ` (${inc.id})` : ""}`);
  }

  function reviewEsc(id: string, ok: boolean) {
    const e = escalations.find((x) => x.id === id);
    setEscalations((es) => es.map((x) => (x.id === id ? { ...x, status: ok ? "approved" : "rejected", reviewedBy: user.name } : x)));
    log(ok ? "Escalation approved" : "Escalation rejected", `${e?.incident ?? "No incident"} from ${e?.from}`);
  }
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);
  useEffect(() => { if (!busy) taRef.current?.focus(); }, [busy]);

  async function respond(history: ChatMessage[], lastText: string, isOutput: boolean) {
    setBusy(true);
    let reply: RelayReply | null = null;
    if (!backup) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 8000);
      try {
        const res = await fetch("/api/relay", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: ctrl.signal,
          body: JSON.stringify({ messages: toConvo(history), now, userId: user.id, knowledge }),
        });
        if (!res.ok) throw new Error(String(res.status));
        reply = await res.json();
      } catch {
        setBackup(true);
      } finally {
        clearTimeout(timer);
      }
    }
    if (!reply) reply = scriptedReply(lastText, isOutput, { now, role: user.role, history });
    const completedReply = reply;
    setMessages((m) => [...m, { id: uid(), kind: "assistant", reply: completedReply, status: "idle" }]);
    setBusy(false);
  }

  function send(text: string) {
    const t = text.trim();
    if (!t || busy) return;
    const next: ChatMessage[] = [...messages, { id: uid(), kind: "user", text: t }];
    setMessages(next);
    setInput("");
    log("Asked Ouroboros", t);
    void respond(next, t, false);
  }

  function setStatus(id: string, status: Extract<ChatMessage, { kind: "assistant" }>["status"], requestedBy?: string) {
    setMessages((ms) => ms.map((m) => (m.id === id && m.kind === "assistant" ? { ...m, status, requestedBy: requestedBy ?? m.requestedBy } : m)));
  }

  function run(id: string, cmd: string, by: string) {
    const lines = commandOutput(cmd, now);
    log("Command run", cmd, by);
    setStatus(id, "ran");
    const out: ChatMessage = { id: uid(), kind: "output", command: cmd, lines, ranBy: by };
    const next = [...messages.map((m) => (m.id === id && m.kind === "assistant" ? { ...m, status: "ran" as const } : m)), out];
    setMessages(next);
    void respond(next, lines.join("\n"), true);
  }

  function approve(id: string, cmd: string) {
    const d = decide(user.role, commands[cmd]!.risk);
    log("Approved suggestion", cmd);
    if (d === "run") return run(id, cmd, user.name);
    if (d === "confirm") return setStatus(id, "confirming");
    if (d === "needs_senior") {
      log("Requested senior sign-off", `${cmd} → ${onCallSenior.name}`);
      return setStatus(id, "awaiting_senior", user.name);
    }
    log("Blocked", `${roleLabels[user.role]} cannot run commands`);
    setStatus(id, "blocked");
  }

  function submitFix(reply: RelayReply) {
    const id = `RB-${String(50 + knowledge.length).padStart(3, "0")}`;
    setKnowledge((k) => [
      ...k,
      {
        id, title: reply.likely_cause ?? "New fix", incident_type: "submitted", steps: [reply.answer, ...(reply.next_if_confirmed ? [reply.next_if_confirmed] : [])],
        source_type: "senior_note", status: "pending", submitted_by: user.id, submitted_at: `2026-10-17T${String(Math.floor(now / 60)).padStart(2, "0")}:${String(now % 60).padStart(2, "0")}`,
        reviewed_by: null, reviewed_at: null, times_used: 0, note: "Submitted from chat. Awaiting a second senior.",
      },
    ]);
    log("Submitted knowledge", `${id} for two-person review`);
  }

  return (
    <div className="glass flex min-h-0 flex-1 flex-col overflow-hidden bg-workspace-chat">
      <div className="flex items-center gap-3 border-b border-border px-4 py-3">
        <Logo className="size-7" />
        <div>
          <div className="text-sm font-semibold">Ask Ouroboros</div>
          <div className="text-xs text-muted-foreground">Suggests. Never runs anything without your approval.</div>
        </div>
        <div className="ml-auto text-right text-[11px] text-muted-foreground">{user.name}<br />{roleLabels[user.role]}</div>
      </div>

      {pendingEsc.length > 0 && (
        <div className="space-y-2 border-b border-border bg-caution/10 px-4 py-3">
          {pendingEsc.map((e) => (
            <div key={e.id} className="flex flex-wrap items-center gap-2 text-xs">
              <RiskBadge value="pending" />
              <span className="flex-1"><span className="font-medium">{e.from}</span> paged {e.to} at {e.sim}{e.incident ? ` · ${e.incident}` : ""}: {e.summary}</span>
              {canApproveOthers(user) && user.name !== e.from ? (
                <>
                  <Button size="sm" onClick={() => reviewEsc(e.id, true)}>Approve</Button>
                  <Button size="sm" variant="ghost" onClick={() => reviewEsc(e.id, false)}>Reject</Button>
                </>
              ) : (
                <span className="text-caution">Awaiting senior approval</span>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4">
        {messages.length === 0 && (
          <div className="space-y-3 pt-6 text-center">
            <p className="text-sm text-muted-foreground">Ask in plain English. I'll read the metrics, alerts and expert runbooks.</p>
            <div className="flex flex-wrap justify-center gap-2">
              {starters.map((s) => (
                <button key={s} onClick={() => send(s)} className="rounded-full border border-border px-3 py-1.5 text-xs hover:border-primary hover:text-foreground">{s}</button>
              ))}
            </div>
          </div>
        )}
        {messages.map((m) => {
          if (m.kind === "user")
            return <div key={m.id} className="ml-auto max-w-[85%] rounded-2xl rounded-br-sm bg-primary px-4 py-2 text-sm text-primary-foreground">{m.text}</div>;
          if (m.kind === "output")
            return (
              <div key={m.id} className="rounded-xl bg-terminal p-3 font-mono text-xs text-terminal-foreground">
                <div className="mb-1 text-terminal-accent">&gt; {m.command} <span className="opacity-60">· run by {m.ranBy} · simulated output</span></div>
                {m.lines.map((l, i) => <div key={i} className="whitespace-pre">{l}</div>)}
              </div>
            );
          const r = m.reply;
          const cmd = r.suggested_command && commands[r.suggested_command] ? r.suggested_command : null;
          return (
            <div key={m.id} className="space-y-2 text-sm">
              {r.headline && <p className="font-semibold leading-snug text-foreground">{r.headline}</p>}
              <p className="leading-relaxed">{r.answer}</p>
              {r.likely_cause && (
                <div className="rounded-lg border border-border bg-card px-3 py-2 text-xs">
                  <span className="font-medium text-foreground">Likely cause</span>{" "}
                  {r.confidence !== "N/A" && (
                    <span title={r.confidence_reason ?? "Confidence reflects how closely the data matches a reviewed runbook, and whether a check has confirmed it."} className="cursor-help rounded border border-border px-1.5 py-0.5 font-mono text-[10px] uppercase underline decoration-dotted">
                      {r.confidence.toLowerCase()} confidence
                    </span>
                  )}
                  <span className="text-muted-foreground">: {r.likely_cause}</span>
                  {r.confidence_reason && <div className="mt-1 text-[11px] text-muted-foreground">Why {r.confidence.toLowerCase()}? {r.confidence_reason}</div>}
                </div>
              )}
              {cmd && (
                <div className="rounded-xl border border-border bg-card p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <code className="font-mono text-sm font-semibold text-primary">{cmd}</code>
                    <RiskBadge value={commands[cmd]!.risk} />
                    <span className="ml-auto font-mono text-[10px] text-muted-foreground">confidence {r.confidence}</span>
                  </div>
                  {r.why && <p className="mt-2 text-xs">{r.why}</p>}
                  {commands[cmd]!.impact && <p className="mt-1 text-xs text-caution">Impact: {commands[cmd]!.impact}</p>}
                  <p className="mt-1 text-[11px] text-muted-foreground">Source: {r.source ?? commands[cmd]!.source}</p>
                  {r.look_for && <p className="mt-2 border-l-2 border-primary pl-2 text-xs"><span className="font-medium">What to look for:</span> {r.look_for}</p>}
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {m.status === "idle" && (
                      <>
                        <Button size="sm" onClick={() => approve(m.id, cmd)} disabled={busy}>Approve & run</Button>
                        <Button size="sm" variant="ghost" onClick={() => { setStatus(m.id, "rejected"); log("Rejected suggestion", cmd); }}>Reject</Button>
                      </>
                    )}
                    {m.status === "confirming" && (
                      <>
                        <span className="text-xs text-caution">This changes the live system. Confirm?</span>
                        <Button size="sm" variant="destructive" onClick={() => run(m.id, cmd, user.name)}>Confirm & run</Button>
                        <Button size="sm" variant="ghost" onClick={() => setStatus(m.id, "idle")}>Cancel</Button>
                      </>
                    )}
                    {m.status === "awaiting_senior" && (
                      canApproveOthers(user) ? (
                        <Button size="sm" variant="destructive" onClick={() => { log("Senior sign-off", `${cmd} for ${m.requestedBy}`); run(m.id, cmd, `${user.name} (sign-off for ${m.requestedBy})`); }}>
                          Sign off & run as {user.name}
                        </Button>
                      ) : (
                        <span className="flex items-center gap-2 text-xs text-caution"><span className="pulse-dot size-1.5 rounded-full bg-caution" />Waiting for sign-off from {onCallSenior.name} (on call)</span>
                      )
                    )}
                    {m.status === "ran" && <span className="text-xs text-safe">✓ Ran</span>}
                    {m.status === "rejected" && <span className="text-xs text-muted-foreground">Rejected</span>}
                    {m.status === "blocked" && <span className="text-xs text-danger">Your role can't run commands.</span>}
                  </div>
                </div>
              )}
              {!cmd && r.needs_senior && (
                <div className="flex items-center gap-2 rounded-xl border border-caution/40 bg-caution/10 p-3 text-xs">
                  Escalate to {onCallSenior.name}, on call.
                  <Button size="sm" variant="outline" className="ml-auto" onClick={() => page(r)}>Page {onCallSenior.name}</Button>
                </div>
              )}
              {r.next_if_confirmed && (
                <div className="rounded-xl border-2 border-caution/60 bg-caution/10 p-3">
                  <div className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-caution">Stop point · escalation</div>
                  <p className="text-sm font-medium text-foreground">{r.next_if_confirmed}</p>
                </div>
              )}
              {r.evidence.length > 0 && (
                <details className="text-xs">
                  <summary className="cursor-pointer text-muted-foreground hover:text-foreground">Evidence ({r.evidence.length} items)</summary>
                  <ul className="mt-2 flex flex-wrap gap-1.5">
                    {r.evidence.map((e) => <li key={e} className="rounded-md bg-muted px-2 py-0.5 font-mono text-[11px] text-muted-foreground">{e}</li>)}
                  </ul>
                </details>
              )}
              {r.offer_save_to_knowledge && canSubmitKnowledge(user) && (
                <Button size="sm" variant="outline" onClick={() => submitFix(r)}>Submit this fix for review</Button>
              )}
            </div>
          );
        })}
        {busy && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Logo className="size-4 animate-spin" /> Reading metrics, alerts and runbooks…
          </div>
        )}
        <div ref={endRef} />
      </div>

      <form
        className="border-t border-border p-3"
        onSubmit={(e) => { e.preventDefault(); send(input); }}
      >
        <div className={cn("flex items-end gap-2 rounded-xl border border-input bg-card p-2 focus-within:border-primary")}>
          <textarea
            ref={taRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }}
            rows={2}
            placeholder="e.g. Why are payments slow?"
            className="flex-1 resize-none bg-transparent px-2 py-1 text-sm outline-none placeholder:text-muted-foreground"
          />
          <Button type="submit" size="sm" disabled={busy || !input.trim()}>Ask</Button>
        </div>
      </form>
    </div>
  );
}
