import { useState } from "react";
import { Area, AreaChart, CartesianGrid, Legend, Line, LineChart, ReferenceArea, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { eventsUntil, incidentAt, metricAt, metricsUntil } from "@/lib/relay-data";
import { useRelay } from "@/lib/store";
import { cn } from "@/lib/utils";
import { RiskBadge } from "./RiskBadge";

const NORMAL = { tps: 490, response_ms: 55, pay1_queue: 12, disk_data01_pct: 72 };

function Kpi({ label, value, unit, bad, hint }: { label: string; value: string; unit?: string; bad?: boolean; hint: string }) {
  return (
    <div className="glass p-4">
      <div className="flex items-center justify-between">
        <div className="text-xs font-medium text-muted-foreground">{label}</div>
        {bad && <span className="rounded-full border border-danger/40 px-2 py-0.5 text-[10px] font-medium text-danger">Attention</span>}
      </div>
      <div className="mt-1 text-[26px] font-bold leading-tight tabular-nums text-foreground">
        {value}
        <span className="ml-1 text-sm text-muted-foreground">{unit}</span>
      </div>
      <div className="mt-1 text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}

const tabs = [
  { key: "cpu", label: "CPU per processor" },
  { key: "tps", label: "Transactions / s" },
  { key: "response_ms", label: "Response time" },
  { key: "pay1_queue", label: "$PAY1 queue" },
  { key: "disk_data01_pct", label: "Disk $DATA01" },
] as const;

export function HealthPanel() {
  const { now } = useRelay();
  const [tab, setTab] = useState<(typeof tabs)[number]["key"]>("cpu");
  const m = metricAt(now);
  const data = metricsUntil(now, 360);
  const inc = incidentAt(now);
  const cpuDown = [m.cpu0_pct, m.cpu1_pct, m.cpu2_pct, m.cpu3_pct].findIndex((c) => c < 3);
  const hotCpu = Math.max(m.cpu0_pct, m.cpu1_pct, m.cpu2_pct, m.cpu3_pct);
  const evs = eventsUntil(now);
  const alerts = [...evs].sort((a, b) => a.severity_rank - b.severity_rank || b.time.localeCompare(a.time)).slice(0, 8);
  const runs: { x1: string; x2: string }[] = [];
  data.forEach((d, i) => {
    if (!(d as { a?: number }).a) return;
    const prev = data[i - 1] as { a?: number } | undefined;
    const end = data[i + 1]?.t ?? d.t;
    if (prev?.a && runs.length) runs[runs.length - 1]!.x2 = end;
    else runs.push({ x1: d.t, x2: end });
  });
  const nowT = data[data.length - 1]?.t;
  const shading = [
    ...runs.map((r) => <ReferenceArea key={r.x1} x1={r.x1} x2={r.x2} fill="#f87171" fillOpacity={0.18} ifOverflow="hidden" />),
    nowT ? <ReferenceLine key="now" x={nowT} stroke="var(--foreground)" strokeDasharray="4 3" strokeOpacity={0.7} /> : null,
  ];

  return (
    <div className="flex flex-col gap-4 bg-workspace-monitor">
      <div className="grid grid-cols-2 gap-3">
        <Kpi label="Transactions" value={String(Math.round(m.tps))} unit="tps" bad={m.tps < NORMAL.tps * 0.7} hint={`normal ~${NORMAL.tps}`} />
        <Kpi label="Response" value={String(Math.round(m.response_ms))} unit="ms" bad={m.response_ms > NORMAL.response_ms * 1.6} hint={`normal ~${NORMAL.response_ms} ms`} />
        <Kpi
          label="CPUs"
          value={cpuDown >= 0 ? `CPU ${cpuDown}` : `${Math.round(hotCpu)}%`}
          unit={cpuDown >= 0 ? "down" : ""}
          bad={cpuDown >= 0 || hotCpu > 85}
          hint={cpuDown >= 0 ? `takeover load ${Math.round(hotCpu)}%` : "busiest processor"}
        />
        <Kpi label="Disk $DATA01" value={String(Math.round(m.disk_data01_pct))} unit="%" bad={m.disk_data01_pct > 85} hint="audit trail volume" />
      </div>

      <div className="glass aurora-panel p-4">
        <div className="mb-3 flex flex-wrap gap-1">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn("rounded-full px-3 py-1 text-xs", tab === t.key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}
            >
              {t.label}
            </button>
          ))}
          <span className="ml-auto self-center font-mono text-[10px] text-muted-foreground">shaded = anomaly (z-score + Isolation Forest)</span>
        </div>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            {tab === "cpu" ? (
              <LineChart data={data}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="t" stroke="var(--muted-foreground)" fontSize={10} minTickGap={40} />
                <YAxis stroke="var(--muted-foreground)" fontSize={10} domain={[0, 100]} width={30} />
                <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 10, fontSize: 12 }} />
                {shading}
                <Legend wrapperStyle={{ fontSize: 10 }} iconType="plainline" iconSize={12} />
                {(["cpu0_pct", "cpu1_pct", "cpu2_pct", "cpu3_pct"] as const).map((k, i) => (
                  <Line key={k} dataKey={k} name={`CPU ${i}`} dot={false} strokeWidth={1.6} stroke={`var(--chart-${i + 1})`} isAnimationActive={false} />
                ))}
              </LineChart>
            ) : (
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="fillSig" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stopColor="var(--primary)" stopOpacity={0.45} />
                    <stop offset="1" stopColor="var(--primary)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="t" stroke="var(--muted-foreground)" fontSize={10} minTickGap={40} />
                <YAxis stroke="var(--muted-foreground)" fontSize={10} width={40} />
                <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 10, fontSize: 12 }} />
                {shading}
                <Area dataKey={tab} stroke="var(--primary)" fill="url(#fillSig)" strokeWidth={1.8} isAnimationActive={false} />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      <div className="glass p-4">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-sm font-semibold">Alerts from your monitoring tools</h2>
          <span className="text-[11px] text-muted-foreground">sorted by urgency (level 1 = most urgent)</span>
        </div>
        <ul className="divide-y divide-border">
          {alerts.map((e) => (
            <li key={e.time + e.message} className="flex items-center gap-3 py-2 text-sm">
              <span className="font-mono text-xs text-muted-foreground">{e.time.slice(11)}</span>
              <RiskBadge value={e.severity} />
              <span className="flex-1">{e.message}</span>
              <span className="hidden font-mono text-[10px] text-muted-foreground sm:inline">{e.source.replace(" (simulated)", "")} · level {e.severity_rank} of 4</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
