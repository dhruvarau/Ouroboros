import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Activity, BookOpen, ClipboardList, Info } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { fmtMin, incidentAt, roleLabels, scenarios, users } from "@/lib/relay-data";
import { useRelay } from "@/lib/store";
import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-8", className)} aria-hidden>
      <circle cx="16" cy="16" r="11" fill="none" stroke="currentColor" strokeWidth="3.5" strokeDasharray="60 9" strokeLinecap="round" transform="rotate(-60 16 16)" />
      <circle cx="23.5" cy="7.8" r="2.6" fill="currentColor" />
    </svg>
  );
}

const nav = [
  { to: "/", label: "Mission Control", icon: Activity },
  { to: "/knowledge", label: "Knowledge Base", icon: BookOpen },
  { to: "/audit", label: "Audit Log", icon: ClipboardList },
  { to: "/about", label: "About", icon: Info },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { now, setNow, user, setUserId } = useRelay();
  const inc = incidentAt(now);
  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar px-4 py-6 md:flex">
        <Link to="/" className="flex items-center gap-2.5 px-2">
          <Logo className="size-7 text-sidebar-accent-foreground" />
          <div className="leading-tight">
            <div className="text-xl font-semibold tracking-tight text-sidebar-accent-foreground">Ouroboros</div>
            <div className="text-[11px] uppercase tracking-widest text-sidebar-foreground/70">CAIL · HPE NonStop</div>
          </div>
        </Link>
        <div className="my-5 h-px bg-sidebar-border" />
        <nav className="flex flex-col gap-1">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="flex items-center gap-3 rounded-lg border-l-4 border-transparent px-3 py-2.5 text-sm text-sidebar-foreground transition-colors hover:bg-sidebar-accent"
              activeProps={{ className: "border-sidebar-accent-foreground! bg-sidebar-accent font-medium text-sidebar-accent-foreground!" }}
              activeOptions={{ exact: true }}
            >
              <n.icon className="size-4" />
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="mt-auto space-y-2 px-1">
          <label className="text-[11px] font-medium uppercase tracking-wider text-sidebar-foreground/70">Signed in as</label>
          <select
            value={user.id}
            onChange={(e) => setUserId(e.target.value)}
            className="w-full rounded-lg border border-sidebar-border bg-sidebar-field px-2.5 py-2 text-sm text-sidebar-accent-foreground"
            aria-label="Signed in as"
          >
            {users.map((u) => (
              <option key={u.id} value={u.id}>
                {u.name} · {roleLabels[u.role]}{u.on_call ? " (on call)" : ""}
              </option>
            ))}
          </select>
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-40 border-b border-border bg-background">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 px-6 py-3">
            <div className="flex items-center gap-2 md:hidden">
              <Logo className="size-6 text-primary" />
              <span className="font-semibold text-primary">Ouroboros</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {scenarios.map((s) => (
                <button
                  key={s.label}
                  onClick={() => setNow(s.time)}
                  className={cn(
                    "whitespace-nowrap rounded-full border px-3 py-1 text-xs transition-colors",
                    Math.abs(now - s.time) < 1 ? "border-primary bg-accent font-medium text-accent-foreground" : "border-border bg-card text-muted-foreground hover:text-foreground",
                  )}
                >
                  {fmtMin(s.time)} · {s.label}
                </button>
              ))}
            </div>
            <div className="ml-auto flex items-center gap-3">
              <span className="rounded-full border border-primary/30 bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">Demo environment</span>
              <span className={cn("size-2 rounded-full", inc ? "pulse-dot bg-danger" : "bg-safe")} />
              <span className="font-mono text-sm">\PROD1 · {fmtMin(now)}</span>
              <Slider className="w-32" min={0} max={1439} step={1} value={[now]} onValueChange={(v) => setNow(v[0] ?? now)} aria-label="Replay time" />
              <select
                value={user.id}
                onChange={(e) => setUserId(e.target.value)}
                className="rounded-lg border border-input bg-card px-2 py-1 text-xs md:hidden"
                aria-label="Signed in as (mobile)"
              >
                {users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
              </select>
            </div>
          </div>
        </header>
        {children}
      </div>
    </div>
  );
}
